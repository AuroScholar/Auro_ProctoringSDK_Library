package com.example.auroproctoringsdk.detector

enum class LensFacing { BACK, FRONT }